﻿-- Breeding Calculator configuration.
-- language: "auto" (follows your Steam game language), "pt-BR" or "en".
return { lua_ui = "auto", language = "auto" }
