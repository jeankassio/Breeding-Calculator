﻿-- Breeding Calculator configuration.
-- language: "auto" (English on Game Pass), "pt-BR" or "en".
return { lua_ui = "auto", language = "auto" }
